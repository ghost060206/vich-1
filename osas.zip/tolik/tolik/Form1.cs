﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tolik
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ПодписатьВсеКнопки();
        }

        private void ПодписатьВсеКнопки()
        {
            foreach (Control элемент in this.Controls)
            {
                if (элемент is Button кнопка)
                {
                    // Настройка внешнего вида
                    кнопка.FlatStyle = FlatStyle.Flat;
                    кнопка.FlatAppearance.BorderSize = 0;
                    кнопка.UseVisualStyleBackColor = false;

                    // Подписка на событие
                    кнопка.Click += (отправитель, аргументы) =>
                    {
                        Button кнопкаНажата = отправитель as Button;

                        // Тернарный оператор для смены цвета
                        кнопкаНажата.BackColor = кнопкаНажата.BackColor == Color.White
                            ? Color.Black
                            : Color.White;

                        // Автоматическая смена цвета текста
                        кнопкаНажата.ForeColor = кнопкаНажата.BackColor == Color.Black
                            ? Color.White
                            : Color.Black;

                        // Снятие фокуса для удаления рамки
                        this.Focus();
                    };
                }
            }
        }
    }
}
